package com.cybage.qualitymanagement.dao;

import java.util.ArrayList;

import com.cybage.qualitymanagement.model.TestCaseModel;
import com.cybage.qualitymanagement.model.TestPlanModel;

public interface TestCaseDao {
	ArrayList<String> getTestPlanTitles();
	TestCaseModel addTestCase(TestCaseModel testCaseModel,TestPlanModel testPlanModel);

}
