package com.cybage.qualitymanagement.dao;

import java.util.List;

import com.cybage.qualitymanagement.model.TestPlanModel;

public interface TestPlanDao {

	TestPlanModel addTestPlan(TestPlanModel testPlan);
	TestPlanModel getTestPlan();
	TestPlanModel getTestPlanByTitle(String planTitle);
	List<TestPlanModel> getAllTestPlans();
	TestPlanModel deleteTestPlan(int id);
	TestPlanModel editTestPlan(int id);
	TestPlanModel updateTestPlan(TestPlanModel testPlanModel);
	TestPlanModel getTestPlan(int id);



}
