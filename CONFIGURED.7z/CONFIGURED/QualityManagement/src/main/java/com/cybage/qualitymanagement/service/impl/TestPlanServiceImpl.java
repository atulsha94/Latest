package com.cybage.qualitymanagement.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.qualitymanagement.dao.TestPlanDao;
import com.cybage.qualitymanagement.model.TestPlanModel;
import com.cybage.qualitymanagement.service.TestPlanService;

@Service
@Transactional
public class TestPlanServiceImpl implements TestPlanService {

	@Autowired
	TestPlanDao testPlanDao;

	public TestPlanServiceImpl() {
	System.out.println("in service impl");
	}
	
	@Override
	public TestPlanModel addTestPlan(TestPlanModel testPlanModel) {
	
		return testPlanDao.addTestPlan(testPlanModel);
		
	
	}
	
	@Override
	public TestPlanModel getTestPlan(){
		return testPlanDao.getTestPlan();
	}

	@Override
	public TestPlanModel getTestPlanByTitle(String planTitle) {
		return testPlanDao.getTestPlanByTitle(planTitle);
	}

	@Override
	public List<TestPlanModel> getAllTestPlans() {
		return testPlanDao.getAllTestPlans();
		
	}

	@Override
	public TestPlanModel deleteTestPlan(int id) {

		return testPlanDao.deleteTestPlan(id);
	}

	@Override
	public TestPlanModel editTestPlan(int id) {
		return testPlanDao.editTestPlan(id);
	}

	@Override
	public TestPlanModel updateTestPlan(TestPlanModel testPlanModel) {
		return testPlanDao.updateTestPlan(testPlanModel);
	}

	
	@Override
	public TestPlanModel getTestPlan(int id){
		return testPlanDao.getTestPlan(id);
	}

	
}
