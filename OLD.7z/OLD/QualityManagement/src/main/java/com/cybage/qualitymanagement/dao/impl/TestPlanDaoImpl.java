package com.cybage.qualitymanagement.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.cybage.qualitymanagement.dao.TestPlanDao;
import com.cybage.qualitymanagement.model.TestPlanModel;


@Repository
public class TestPlanDaoImpl implements TestPlanDao {
	
	@Autowired
	SessionFactory sf;
	
	@Autowired
	HibernateTemplate hibernateTemplate;
	
	public TestPlanDaoImpl() {
	System.out.println("in dao impl");
	}
	
	@Override
	public TestPlanModel addTestPlan(TestPlanModel testPlanModel){
		 sf.getCurrentSession().save(testPlanModel);
		 
		 return testPlanModel;
	}
	
	@Override
	public TestPlanModel getTestPlan() {
		/*
		 * @SuppressWarnings("unchecked") ArrayList<String>
		 * c=(ArrayList<String>) sf.getCurrentSession() .createQuery(
		 * "select c.testPlanTitle from TestPlan c") .list(); return c;
		 */
		TestPlanModel testPlanModel = (TestPlanModel) hibernateTemplate.get(TestPlanModel.class, 1);
		return testPlanModel;
	}

	@Override
	public TestPlanModel getTestPlanByTitle(String planTitle) {
		TestPlanModel testPlanModel = (TestPlanModel) sf.getCurrentSession()
				.createQuery("select c from TestPlanModel c where c.testPlanTitle = :title")
				.setParameter("title", planTitle)
				.uniqueResult();
	
		return testPlanModel;
		
	}

	@Override
	public List<TestPlanModel> getAllTestPlans() {
		@SuppressWarnings("unchecked")
		List<TestPlanModel> testPlanList = sf.getCurrentSession().createQuery("from TestPlanModel").list();
			return testPlanList;
	}

	@Override
	public TestPlanModel deleteTestPlan(int id) {
		String status="TestPlan Deletion failed";
		TestPlanModel testPlanModel	 = (TestPlanModel) sf.getCurrentSession().load(TestPlanModel.class, new Integer(id));
		if (testPlanModel!=null) {
		 sf.getCurrentSession().delete(testPlanModel);
		 status="Test Plan with Id"+testPlanModel.getTestPlanId() +"deleted successfully";
		 System.out.println("in DAO"+testPlanModel);
		return testPlanModel;
		}
		else return testPlanModel;
		
	}

	@Override
	public TestPlanModel editTestPlan(int id) {

		Criteria criteria = sf.getCurrentSession().createCriteria(TestPlanModel.class);
		criteria.add(Restrictions.eq("testPlanId", id));
		TestPlanModel testPlanModel = (TestPlanModel) criteria.uniqueResult();
		System.out.println(testPlanModel);
		return testPlanModel;

	}

	@Override
	public TestPlanModel updateTestPlan(TestPlanModel testPlanModel) {
		sf.getCurrentSession().update(testPlanModel);
		return testPlanModel;	
		}
	
	@Override
	public TestPlanModel getTestPlan(int id) {
		/*
		 * @SuppressWarnings("unchecked") ArrayList<String>
		 * c=(ArrayList<String>) sf.getCurrentSession() .createQuery(
		 * "select c.testPlanTitle from TestPlan c") .list(); return c;
		 */
		TestPlanModel testPlanModel = (TestPlanModel) hibernateTemplate.get(TestPlanModel.class, id);
		return testPlanModel;
	}
}
