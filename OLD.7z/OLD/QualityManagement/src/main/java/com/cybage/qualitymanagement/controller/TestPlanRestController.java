package com.cybage.qualitymanagement.controller;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.qualitymanagement.dto.TestPlanDto;
import com.cybage.qualitymanagement.model.TestPlanModel;
import com.cybage.qualitymanagement.service.TestCaseService;
import com.cybage.qualitymanagement.service.TestPlanService;

@RestController
@RequestMapping("/testPlan")
public class TestPlanRestController {
	
	@Autowired
	TestPlanService testPlanService;
	@Autowired
	TestCaseService testCaseService;
	

	@RequestMapping(value = "/getTestPlan/{id}", method = RequestMethod.GET, headers = "Accept=application/json")
	public TestPlanDto getTestPlans(@PathVariable int id) {
		TestPlanModel testPlanModel = testPlanService.getTestPlan(id);
		ModelMapper modelMapper = new ModelMapper();
		TestPlanDto testPlanDto = modelMapper.map(testPlanModel,TestPlanDto.class);
		return testPlanDto;
	}
		
	
	@RequestMapping(value = "/addTestPlan", method = RequestMethod.POST, headers = "Accept=application/json")
	public void addTestPlan(@RequestBody TestPlanDto testPlanDto) {
		
		ModelMapper modelMapper = new ModelMapper();
		TestPlanModel testPlanModel = modelMapper.map(testPlanDto,TestPlanModel.class);
		testPlanService.addTestPlan(testPlanModel);

	
	}
	
	@RequestMapping(value = "/delete/{id}", method = RequestMethod.GET, headers = "Accept=application/json")
	public TestPlanDto deleteTestPlan(@PathVariable int id) {
		
		TestPlanModel testPlanModel = testPlanService.deleteTestPlan(id);
		ModelMapper modelMapper = new ModelMapper();
		TestPlanDto testPlanDto = modelMapper.map(testPlanModel,TestPlanDto.class);
		System.out.println("in controller"+testPlanDto);
		return testPlanDto;
	
	}
	
	@RequestMapping(value = "/edit/updateTestPlan", method = RequestMethod.POST)
	public ResponseEntity<List<TestPlanModel>> editTestPlan(@RequestBody TestPlanDto testPlanDto) {

		
		ModelMapper modelMapper = new ModelMapper();
		TestPlanModel testPlanModel = modelMapper.map(testPlanDto,TestPlanModel.class);
		testPlanService.updateTestPlan(testPlanModel);
		List<TestPlanModel> testPlanModelList = testPlanService.getAllTestPlans();
		if (testPlanModelList.isEmpty()) {
			return new ResponseEntity<List<TestPlanModel>>(HttpStatus.NO_CONTENT);

		}
		return new ResponseEntity<List<TestPlanModel>>(testPlanModelList, HttpStatus.OK);
		}
	

	@RequestMapping(value = "/viewAll", method = RequestMethod.GET)
	public ResponseEntity<List<TestPlanModel>> viewAllTestPlan() {
		List<TestPlanModel> testPlanModelList = testPlanService.getAllTestPlans();
		if (testPlanModelList.isEmpty()) {
			return new ResponseEntity<List<TestPlanModel>>(HttpStatus.NO_CONTENT);

		}
		return new ResponseEntity<List<TestPlanModel>>(testPlanModelList, HttpStatus.OK);
	}
	
	

}
